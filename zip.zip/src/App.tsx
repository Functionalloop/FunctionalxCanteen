import { useState } from 'react';
import { Home, ClipboardList, Activity, Wallet, LayoutDashboard } from 'lucide-react';
import { cn } from './lib/utils';
import StudentHome from './components/StudentHome';
import StudentQueue from './components/StudentQueue';
import StudentWellness from './components/StudentWellness';
import StudentWallet from './components/StudentWallet';
import VendorDashboard from './components/VendorDashboard';
import StudentCheckout from './components/StudentCheckout';
import StudentProfile from './components/StudentProfile';

type Tab = 'home' | 'queue' | 'wellness' | 'wallet' | 'vendor';
type Screen = 'main' | 'checkout' | 'profile';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [activeScreen, setActiveScreen] = useState<Screen>('main');

  const handleNavigate = (screen: Screen, tab?: Tab) => {
    setActiveScreen(screen);
    if (tab) setActiveTab(tab);
  };

  return (
    <div className="min-h-screen bg-black text-zinc-100 font-sans pb-20 md:pb-0 flex flex-col md:flex-row">
      {/* Main Content Area */}
      <main className={cn("flex-1 mx-auto w-full bg-black md:border-r md:border-zinc-800 relative z-0 overflow-y-auto overflow-x-hidden", activeTab === 'vendor' ? "max-w-6xl" : "max-w-md")}>
        {activeScreen === 'main' && (
          <>
            {activeTab === 'home' && <StudentHome onNavigate={handleNavigate} />}
            {activeTab === 'queue' && <StudentQueue onNavigate={handleNavigate} />}
            {activeTab === 'wellness' && <StudentWellness />}
            {activeTab === 'wallet' && <StudentWallet onNavigate={handleNavigate} />}
            {activeTab === 'vendor' && <VendorDashboard />}
          </>
        )}
        
        {activeScreen === 'checkout' && <StudentCheckout onBack={() => handleNavigate('main')} />}
        {activeScreen === 'profile' && <StudentProfile onBack={() => handleNavigate('main')} />}
        
        {/* Mobile Bottom Navigation (Hidden when vendor view is active) */}
        {activeTab !== 'vendor' && activeScreen === 'main' && (
          <nav className="fixed bottom-0 w-full max-w-md bg-zinc-950 border-t border-zinc-900 z-50 px-6 py-3 pb-safe flex justify-between items-center">
            <NavItem 
              icon={<Home size={24} />} 
              label="Home" 
              isActive={activeTab === 'home'} 
              onClick={() => setActiveTab('home')} 
            />
            <NavItem 
              icon={<ClipboardList size={24} />} 
              label="Queue" 
              isActive={activeTab === 'queue'} 
              onClick={() => setActiveTab('queue')} 
            />
            <NavItem 
              icon={<Activity size={24} />} 
              label="Wellness" 
              isActive={activeTab === 'wellness'} 
              onClick={() => setActiveTab('wellness')} 
            />
            <NavItem 
              icon={<Wallet size={24} />} 
              label="Wallet" 
              isActive={activeTab === 'wallet'} 
              onClick={() => setActiveTab('wallet')} 
            />
          </nav>
        )}
      </main>

      {/* Desktop sidebar/portal toggle (for demo purposes) */}
      <div className="hidden md:flex w-64 p-6 bg-zinc-950 border-l border-zinc-900 flex-col gap-6">
        <h2 className="text-xl font-semibold text-white tracking-tight">FunctionalCanteen</h2>
        <div className="flex flex-col gap-2">
          <p className="text-xs text-zinc-500 font-medium uppercase tracking-wider mb-2">View Modes</p>
          <button 
            onClick={() => setActiveTab('home')}
            className={cn("text-left px-4 py-2 rounded-lg text-sm transition-colors", activeTab !== 'vendor' ? "bg-rose-600/10 text-rose-600 font-medium" : "text-zinc-400 hover:text-white hover:bg-zinc-900")}
          >
            Student App
          </button>
          <button 
            onClick={() => setActiveTab('vendor')}
            className={cn("text-left px-4 py-2 rounded-lg text-sm transition-colors", activeTab === 'vendor' ? "bg-rose-600/10 text-rose-600 font-medium" : "text-zinc-400 hover:text-white hover:bg-zinc-900 flex items-center gap-2")}
          >
            <LayoutDashboard size={16} />
            Vendor Portal
          </button>
        </div>
      </div>
    </div>
  );
}

function NavItem({ icon, label, isActive, onClick }: { icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick} 
      className={cn(
        "flex flex-col items-center gap-1 transition-colors duration-200", 
        isActive ? "text-rose-600" : "text-zinc-500 hover:text-zinc-300"
      )}
    >
      {icon}
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );
}

