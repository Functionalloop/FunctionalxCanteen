import { MenuItem, Broadcast, WalletTransaction } from './types';

export const mockMenu: MenuItem[] = [
  {
    id: '1',
    name: 'Tandoori Pizza',
    price: 350.00,
    dietary: 'Veg',
    allergens: ['Dairy', 'Gluten'],
    status: 'Available',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=600',
    rating: 4.3,
    reviews: 27,
    prepTime: '15-30 min',
    distance: '1.3 km'
  },
  {
    id: '2',
    name: 'Burger Deluxe',
    price: 180.00,
    dietary: 'Non-Veg',
    allergens: ['Gluten', 'Dairy', 'Egg'],
    status: 'Running Low',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=600',
    rating: 4.7,
    reviews: 35,
    prepTime: '20-35 min',
    distance: '2.5 km'
  },
  {
    id: '3',
    name: 'Chinese Fried Noodles',
    price: 120.00,
    dietary: 'Veg',
    allergens: ['Gluten'],
    status: 'Available',
    image: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&q=80&w=600',
    rating: 4.5,
    reviews: 42,
    prepTime: '20-35 min',
    distance: '2.1 km'
  },
  {
    id: '4',
    name: 'Rajma Chawal',
    price: 80.00,
    dietary: 'Veg',
    allergens: [],
    status: 'Finished',
    image: 'https://images.unsplash.com/photo-1626082895617-2c6bfcc32746?auto=format&fit=crop&q=80&w=600',
    rating: 4.8,
    reviews: 120,
    prepTime: '5-10 min',
    distance: '0 km (Campus)'
  },
  {
    id: '5',
    name: 'Vada Pav',
    price: 35.00,
    dietary: 'Veg',
    allergens: ['Gluten'],
    status: 'Available',
    image: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&q=80&w=600',
    rating: 4.2,
    reviews: 89,
    prepTime: '5 min',
    distance: '0 km (Campus)'
  }
];

export const mockBroadcasts: Broadcast[] = [
  {
    id: 'b1',
    message: 'Upma finished early. Replacing with Idli from 8:30am',
    type: 'info',
    timestamp: '8:15 AM',
    staffName: 'Ramu (Head Chef)'
  },
  {
    id: 'b2',
    message: 'Main Mess closed for 15 mins due to cleaning.',
    type: 'urgent',
    timestamp: '11:00 AM',
    staffName: 'Admin'
  }
];

export const mockTransactions: WalletTransaction[] = [
  {
    id: 't1',
    type: 'deduction',
    amount: 80.00,
    description: 'Breakfast Pickup (Token #046)',
    timestamp: 'Today, 8:45 AM',
    tokenNo: '#046'
  },
  {
    id: 't2',
    type: 'credit',
    amount: 50.00,
    description: 'Wellness Reward (7-Day Streak)',
    timestamp: 'Yesterday, 10:00 PM'
  },
  {
    id: 't3',
    type: 'credit',
    amount: 2000.00,
    description: 'Parent UPI Top-up',
    timestamp: 'Yesterday, 9:30 AM'
  }
];
