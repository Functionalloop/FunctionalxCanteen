export type Allergen = 'Gluten' | 'Dairy' | 'Egg' | 'Nuts' | 'Peanuts';
export type Dietary = 'Veg' | 'Non-Veg' | 'Egg';
export type MenuStatus = 'Available' | 'Running Low' | 'Finished';

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  dietary: Dietary;
  allergens: Allergen[];
  status: MenuStatus;
  image?: string;
  rating: number;
  reviews: number;
  prepTime: string;
  distance: string;
}

export interface Broadcast {
  id: string;
  message: string;
  type: 'info' | 'urgent';
  timestamp: string;
  staffName: string;
}

export interface WalletTransaction {
  id: string;
  type: 'deduction' | 'credit';
  amount: number;
  description: string;
  timestamp: string;
  tokenNo?: string;
}
