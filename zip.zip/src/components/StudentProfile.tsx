import { User, Lock, Bell, Shield, Globe, CreditCard, FileText, HelpCircle, ChevronRight, ArrowRight } from 'lucide-react';

export default function StudentProfile({ onBack }: { onBack: () => void }) {
  return (
    <div className="flex flex-col min-h-screen bg-black text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-6 pb-2">
        <h1 className="text-2xl font-bold">Profile</h1>
      </div>

      <div 
        className="px-6 py-4 flex items-center justify-between cursor-pointer hover:bg-white/5 transition-colors rounded-2xl mx-4 mb-2"
        onClick={onBack}
      >
         <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-zinc-800 rounded-full overflow-hidden shrink-0 border border-zinc-700">
               <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="Profile" className="w-full h-full object-cover" />
            </div>
            <div>
               <h2 className="text-base font-bold text-rose-600">Jenny Wilson</h2>
               <p className="text-xs text-zinc-500">wilson@09gail.com</p>
            </div>
         </div>
         <ArrowRight size={20} className="text-sky-500" />
      </div>

      <div className="flex-1 overflow-y-auto px-6 space-y-6 pb-12 hide-scrollbar">
        
        {/* General */}
        <div>
           <h3 className="text-[13px] font-medium text-zinc-400 mb-3 ml-1">General</h3>
           <div className="space-y-2">
              <ProfileItem icon={<User size={18}/>} label="Edit Profile" />
              <ProfileItem icon={<Lock size={18}/>} label="Change Password" />
              <ProfileItem icon={<Bell size={18}/>} label="Notifications" />
              <ProfileItem icon={<Shield size={18}/>} label="Security" />
              <ProfileItem icon={<Globe size={18}/>} label="Language" />
              <ProfileItem icon={<CreditCard size={18}/>} label="Payment Account" />
           </div>
        </div>

        {/* Preferences */}
        <div>
           <h3 className="text-[13px] font-medium text-zinc-400 mb-3 ml-1">Preferences</h3>
           <div className="space-y-2">
              <ProfileItem icon={<FileText size={18}/>} label="Legal and Policies" />
              <ProfileItem icon={<HelpCircle size={18}/>} label="Help & Support" />
           </div>
        </div>

        <button className="w-full mt-4 flex items-center justify-center p-4 rounded-2xl border border-zinc-800 text-sm font-medium text-white hover:bg-zinc-900 transition-colors">
          Log out
        </button>

      </div>
    </div>
  );
}

function ProfileItem({ icon, label }: { icon: React.ReactNode, label: string }) {
  return (
    <div className="flex items-center justify-between p-4 bg-[#18181B] rounded-2xl border border-white/5 cursor-pointer hover:bg-zinc-900 transition-colors">
       <div className="flex items-center gap-3">
          <div className="text-zinc-400">{icon}</div>
          <span className="text-sm font-bold text-white">{label}</span>
       </div>
       <ChevronRight size={18} className="text-zinc-600" />
    </div>
  );
}
