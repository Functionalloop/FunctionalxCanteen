import { Ticket, Clock, CheckCircle2, ChevronRight, Moon, Users } from 'lucide-react';

export default function StudentQueue({ onNavigate }: { onNavigate: (screen: 'checkout') => void }) {
  return (
    <div className="px-6 py-12 flex flex-col min-h-screen">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Queue & Orders</h1>
        <p className="text-sm text-zinc-400">Track your food and predict crowds.</p>
      </div>

      <div className="space-y-6">
        {/* Active Smart Queue */}
        <div className="bg-[#18181B] border border-rose-600/20 rounded-2xl p-5 relative overflow-hidden shadow-lg">
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-600/5 rounded-full blur-2xl"></div>
          
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-xs text-rose-600 font-bold uppercase tracking-wider mb-1">Your Token</p>
              <div className="text-4xl font-black text-white">#047</div>
            </div>
            <div className="text-right">
              <p className="text-xs text-zinc-500 font-medium mb-1">Estimated Wait</p>
              <div className="text-2xl font-bold text-white flex items-center gap-1 justify-end">
                <Clock size={18} className="text-rose-600" /> 8m
              </div>
            </div>
          </div>

          <div className="mb-5">
            <div className="flex justify-between text-[10px] text-zinc-400 font-medium mb-2 uppercase">
              <span>Currently Serving: #039</span>
              <span>8 tokens ahead</span>
            </div>
            <div className="w-full bg-black rounded-full h-2">
              <div className="bg-rose-600 h-2 rounded-full" style={{ width: '45%' }}></div>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-rose-600/10 rounded-xl p-3 border border-rose-600/20">
            <Ticket className="text-rose-600" size={18} />
            <p className="text-xs text-rose-200 font-medium text-left leading-snug">
              We'll send a push notification when your token is 2 away!
            </p>
          </div>
        </div>

        {/* Peak Hours Predictor */}
        <div className="bg-[#18181B] rounded-2xl p-5 border border-zinc-800">
          <h3 className="font-bold text-white mb-4 text-sm flex items-center gap-2">
             Campus Peak Hours
          </h3>
          
          <div className="space-y-3 mb-4">
            <PeakBar time="12:30 PM" level={30} label="Quiet" />
            <PeakBar time="1:00 PM" level={90} label="Avoid" color="bg-red-500" />
            <PeakBar time="1:30 PM" level={100} label="Peak" color="bg-red-500" />
            <PeakBar time="2:00 PM" level={60} label="Busy" color="bg-amber-500" />
            <PeakBar time="2:30 PM" level={20} label="Quiet" />
          </div>

          <p className="text-[10px] text-zinc-500 text-center">Data seeded from academic timetable.</p>
        </div>

        {/* Night Booking Banner */}
        <button className="w-full bg-indigo-500/10 border border-indigo-500/20 hover:bg-indigo-500/20 rounded-2xl p-4 flex items-center gap-4 transition-colors text-left group">
          <div className="w-10 h-10 rounded-full bg-indigo-500/20 flex flex-col items-center justify-center shrink-0 text-indigo-400 group-hover:scale-110 transition-transform">
            <Moon size={18} />
          </div>
          <div className="flex-1">
            <h4 className="text-indigo-400 font-bold text-sm mb-1">Night Booking Active</h4>
            <p className="text-xs text-indigo-200/60 leading-snug">Book tomorrow's breakfast tonight before midnight.</p>
          </div>
          <ChevronRight size={18} className="text-indigo-400/50" />
        </button>

        {/* Group Order Flow */}
        <button 
          onClick={() => onNavigate('checkout')}
          className="w-full bg-[#18181B] border border-zinc-800 hover:bg-zinc-900 rounded-2xl p-4 flex items-center gap-4 transition-colors text-left group"
        >
          <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center shrink-0 text-zinc-400 group-hover:text-white transition-colors">
            <Users size={18} />
          </div>
          <div className="flex-1">
            <h4 className="text-white font-bold text-sm mb-1">Start Group Order</h4>
            <p className="text-xs text-zinc-500 leading-snug">Split bills instantly, get one master token.</p>
          </div>
          <ChevronRight size={18} className="text-zinc-600 group-hover:text-zinc-400 transition-colors" />
        </button>

      </div>
    </div>
  );
}

function PeakBar({ time, level, label, color = "bg-rose-600" }: { time: string, level: number, label: string, color?: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-14 text-right text-[10px] text-zinc-500 font-medium font-mono">{time}</div>
      <div className="flex-1 h-2.5 bg-black rounded-full overflow-hidden">
        <div className={`h-full ${color} rounded-full`} style={{ width: `${level}%` }}></div>
      </div>
      <div className={`w-10 text-[10px] font-bold ${level > 80 ? 'text-red-500' : level > 50 ? 'text-amber-500' : 'text-zinc-500'}`}>
        {label}
      </div>
    </div>
  );
}
