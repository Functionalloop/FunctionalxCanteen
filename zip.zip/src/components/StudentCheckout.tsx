import { useState } from 'react';
import { ArrowLeft, MapPin, Wallet, Plus, Minus, Users, ChevronRight, Clock, CheckCircle2 } from 'lucide-react';

export default function StudentCheckout({ onBack }: { onBack: () => void }) {
  const [quantity1, setQuantity1] = useState(1);
  const [isGroupOrder, setIsGroupOrder] = useState(false);

  return (
    <div className="flex flex-col min-h-screen bg-black text-white">
      {/* Header */}
      <div className="flex justify-center items-center py-5 relative px-4 border-b border-white/5">
        <button onClick={onBack} className="absolute left-4 p-2 -ml-2 text-white">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-lg font-bold text-white">Checkout</h1>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6 pb-32">
        {/* Items */}
        <div className="space-y-4">
          <div className="bg-[#18181B] rounded-2xl p-4 flex items-center border border-white/5">
            <div className="w-4 h-4 rounded-full border-4 border-rose-600 mr-4 shrink-0"></div>
            <div className="w-14 h-14 rounded-lg overflow-hidden shrink-0 mr-3">
              <img src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=200" alt="Food" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-sm text-white">Burger Deluxe</h3>
              <p className="text-[10px] text-zinc-500">Non-Veg</p>
              <div className="font-bold mt-1 text-sm text-white">₹180.00</div>
            </div>
            <div className="flex items-center bg-zinc-900 rounded-full h-8 px-1">
              <button onClick={() => setQuantity1(Math.max(1, quantity1 - 1))} className="w-6 h-6 flex items-center justify-center text-zinc-400 bg-zinc-800 rounded-full transition-colors hover:text-white"><Minus size={14}/></button>
              <span className="w-8 text-center text-xs font-bold">{String(quantity1).padStart(2, '0')}</span>
              <button onClick={() => setQuantity1(quantity1 + 1)} className="w-6 h-6 flex items-center justify-center text-white bg-zinc-700 rounded-full transition-colors hover:bg-zinc-600"><Plus size={14}/></button>
            </div>
          </div>
        </div>

        {/* Group Order Toggle */}
        <div className="bg-[#18181B] rounded-2xl p-5 border border-rose-600/30 relative overflow-hidden transition-all duration-300">
             <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                <Users size={64} />
             </div>
             <div className="flex justify-between items-center mb-3">
               <div>
                 <h3 className="font-bold text-white text-sm">Group Order Sync</h3>
                 <p className="text-[10px] text-zinc-400">Split bills automatically</p>
               </div>
               <button 
                  onClick={() => setIsGroupOrder(!isGroupOrder)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${isGroupOrder ? 'bg-rose-600' : 'bg-zinc-700'}`}
               >
                  <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${isGroupOrder ? 'left-7' : 'left-1.5'}`}></div>
               </button>
             </div>

             {isGroupOrder && (
               <div className="mt-4 pt-4 border-t border-zinc-800 space-y-3 animate-in fade-in slide-in-from-top-4">
                  <div className="flex items-center justify-between text-xs">
                     <span className="text-zinc-400">Rahul M. (You)</span>
                     <span className="text-white font-bold">₹{(180.00 * quantity1).toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                     <span className="text-zinc-400">Priya K. (Pending)</span>
                     <span className="text-white font-bold">₹0.00</span>
                  </div>
                  <button className="w-full mt-2 py-2 border border-dashed border-zinc-600 rounded-xl text-xs text-sky-500 font-bold hover:bg-sky-500/10 transition-colors">
                    + Add Friend from Contacts
                  </button>
               </div>
             )}
        </div>

        {/* Pre-order Schedule */}
        <div>
          <div className="flex justify-between mb-2">
             <h3 className="font-bold text-sm text-white">Pre-order Details</h3>
          </div>
          <div className="bg-[#18181B] rounded-2xl p-4 border border-white/5 space-y-4">
             <div className="flex justify-between items-center text-sm">
                <span className="text-zinc-400">Est. Preparation Time</span>
                <span className="text-white font-bold text-sky-500">15-20 mins</span>
             </div>
             <div className="h-px bg-zinc-800 w-full my-2"></div>
             <div>
                <span className="text-zinc-400 text-sm mb-3 block">Select Pickup Time</span>
                <div className="flex gap-2 relative overflow-x-auto hide-scrollbar -mx-4 px-4 pb-2">
                   <button className="px-4 py-2 border border-rose-600 bg-rose-600/10 text-rose-600 rounded-xl text-xs font-bold whitespace-nowrap shrink-0">
                      ASAP (~10:40 AM)
                   </button>
                   <button className="px-4 py-2 border border-zinc-700 bg-black hover:bg-zinc-900 text-zinc-300 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-colors">
                      11:00 AM
                   </button>
                   <button className="px-4 py-2 border border-zinc-700 bg-black hover:bg-zinc-900 text-zinc-300 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-colors">
                      11:30 AM
                   </button>
                   <button className="px-4 py-2 border border-zinc-700 bg-black hover:bg-zinc-900 text-zinc-300 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 flex items-center gap-1 transition-colors">
                      Custom <Clock size={12}/>
                   </button>
                </div>
             </div>
             <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-2 text-[10px] text-emerald-400 font-medium">
               <CheckCircle2 size={12} className="inline mr-1" />
               Vendor starts cooking at exactly the right time. Zero waste!
             </div>
          </div>
        </div>

        {/* Pickup Details */}
        <div>
          <div className="flex justify-between mb-2">
             <h3 className="font-bold text-sm text-white">Pickup Location</h3>
             <button className="text-xs text-sky-500 font-medium">Edit</button>
          </div>
          <div className="bg-white rounded-2xl p-4 flex items-center">
            <div className="w-12 h-12 bg-zinc-100 rounded-xl relative mr-3 shrink-0 overflow-hidden">
               <img src="https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&q=80&w=200" alt="Map" className="w-full h-full object-cover" />
               <div className="absolute inset-0 bg-black/20 flex items-center justify-center backdrop-blur-[1px]">
                 <div className="bg-white text-black text-[8px] font-bold px-1.5 py-0.5 rounded shadow-sm relative z-10 -mt-2">Home</div>
                 <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 mt-1">
                   <MapPin size={14} className="text-black fill-white" />
                 </div>
               </div>
            </div>
            <div>
              <p className="text-xs text-black font-medium leading-loose">Main CS Canteen</p>
              <p className="text-[10px] text-zinc-500 font-medium">Pick up in 15-20 mins (Avoid Peak)</p>
            </div>
          </div>
        </div>

        {/* Payment */}
        <div>
          <div className="flex justify-between mb-2">
             <h3 className="font-bold text-sm text-white">Payment Method</h3>
             <button className="text-xs text-sky-500 font-medium">Edit</button>
          </div>
          <div className="bg-[#18181B] rounded-2xl p-4 flex items-center justify-between border border-white/5 cursor-pointer hover:bg-zinc-900 transition-colors">
             <div className="flex items-center gap-3">
               <div className="w-8 h-8 rounded-full bg-rose-600/20 flex items-center justify-center text-rose-600">
                  <Wallet size={16} />
               </div>
               <div>
                  <p className="text-sm font-bold text-white">Campus Wallet</p>
                  <p className="text-[10px] text-zinc-500">Bal: ₹850.50</p>
               </div>
             </div>
             <ChevronRight size={18} className="text-zinc-600" />
          </div>
        </div>

      </div>

      {/* Bottom Bar */}
      <div className="fixed bottom-0 left-0 w-full md:absolute md:w-[448px] bg-black border-t border-zinc-900 p-4 pb-safe space-y-3 z-50">
         <div className="flex justify-between items-center px-2">
           <span className="text-sm font-medium text-zinc-400">Total</span>
           <span className="text-xl font-bold text-white">₹{(180.00 * quantity1).toFixed(2)}</span>
         </div>
         <button className="w-full bg-rose-600 hover:bg-rose-700 text-white font-bold py-4 rounded-2xl text-sm transition-colors text-center">
            Proceed To Checkout
         </button>
      </div>
    </div>
  );
}
