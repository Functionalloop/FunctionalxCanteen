import { useState } from 'react';
import { Bell, Search, MapPin, Heart, Clock, Star, Trophy } from 'lucide-react';
import { cn } from '../lib/utils';
import { mockMenu, mockBroadcasts } from '../data';

export default function StudentHome({ onNavigate }: { onNavigate: (screen: 'checkout' | 'profile') => void }) {
  const [activeMeal, setActiveMeal] = useState('Lunch');
  
  return (
    <div className="flex flex-col min-h-screen bg-black">
      {/* Header section (styled like standard food delivery app) */}
      <div className="bg-gradient-to-br from-rose-600 to-rose-700 rounded-b-3xl px-6 pt-12 pb-6 shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <button 
              className="w-10 h-10 rounded-full bg-rose-500 border-2 border-white/20 overflow-hidden shrink-0 hover:border-rose-400 transition-colors"
              onClick={() => onNavigate('profile')}
            >
              <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="Profile" className="w-full h-full object-cover" />
            </button>
            <div>
              <div className="flex items-center text-white/90 text-sm font-medium">
                Delivery location <span className="ml-1 opacity-70 text-xs">▼</span>
              </div>
              <div className="flex items-center gap-1 text-white font-semibold">
                <MapPin size={14} /> Market Avenue
              </div>
            </div>
          </div>
          <button className="relative w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-white border border-white/10 shrink-0">
            <Bell size={20} />
            <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
        </div>
        
        <h1 className="text-2xl font-bold text-white mb-4">What would you prefer to eat today?</h1>
        
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={20} />
          <input 
            type="text" 
            placeholder="Search menu, categories..." 
            className="w-full bg-black border border-black/10 rounded-full py-3.5 pl-12 pr-4 text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-white/30"
          />
        </div>
      </div>

      <div className="flex-1 px-4 py-4 mb-20 overflow-y-auto hide-scrollbar">
        {/* Broadcast Banner */}
        {mockBroadcasts.map(b => (
          <div key={b.id} className={cn(
            "rounded-xl p-4 flex gap-3 shadow-md mb-6", 
            b.type === 'Info' || b.type === 'info' ? "bg-amber-500/10 border border-amber-500/30" : "bg-red-500/10 border border-red-500/30"
          )}>
            <div className={cn(
              "w-2 h-full rounded-full shrink-0", 
              b.type === 'Info' || b.type === 'info' ? "bg-amber-500" : "bg-red-500"
            )} />
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className={cn("text-xs font-bold uppercase", b.type === 'info' ? "text-amber-500" : "text-red-500")}>
                  {b.type === 'info' ? 'Update' : 'Urgent'}
                </span>
                <span className="text-[10px] text-zinc-500">{b.timestamp} • {b.staffName}</span>
              </div>
              <p className="text-sm text-zinc-300 font-medium leading-snug">{b.message}</p>
            </div>
          </div>
        ))}
        
        {/* Meal Time Tabs */}
        <div className="flex border-b border-zinc-800 mb-6">
          {['Breakfast', 'Lunch', 'Snacks', 'Dinner'].map(meal => (
             <button 
               key={meal}
               onClick={() => setActiveMeal(meal)}
               className={cn(
                  "flex-1 pb-3 text-sm font-semibold transition-colors border-b-2 whitespace-nowrap px-2",
                  activeMeal === meal ? "text-rose-600 border-rose-600" : "text-zinc-500 border-transparent hover:text-zinc-300"
               )}
             >
               {meal}
             </button>
          ))}
        </div>

        {/* What's Special Today Header */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-white text-lg font-bold flex items-center gap-2">
            What's Special Today ✨
          </h2>
          <button className="text-xs text-sky-500 font-semibold hover:text-sky-400">See All</button>
        </div>

        {/* Categories (All, Burgers, Pizza...) */}
        <div className="flex items-center gap-3 overflow-x-auto hide-scrollbar mb-6 -mx-4 px-4">
          <CategoryPill active label="All" />
          <CategoryPill label="🍔 Burgers" />
          <CategoryPill label="🍕 Pizza" />
          <CategoryPill label="🍪 Cookies" />
          <CategoryPill label="🍜 Noodles" />
        </div>

        {/* Horizontal Menu Scroll */}
        <div className="flex overflow-x-auto hide-scrollbar gap-4 -mx-4 px-4 mb-8">
          {[...mockMenu].sort((a, b) => {
            // Simple logic to shuffle based on activeMeal to make them look different
            const scoreA = (a.name.length + activeMeal.length) % 3;
            const scoreB = (b.name.length + activeMeal.length) % 3;
            return scoreA - scoreB;
          }).map(item => (
            <div key={item.id} className="min-w-[200px] bg-[#18181B] rounded-2xl overflow-hidden shrink-0 group relative">
              <div className="absolute top-2 left-2 z-10 bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-md">
                10% Off
              </div>
              <button className="absolute top-2 right-2 z-10 w-7 h-7 rounded-full bg-black/40 flex items-center justify-center backdrop-blur-sm text-white/70 hover:text-white">
                <Heart size={14} />
              </button>
              
              <div className="h-32 w-full relative overflow-hidden bg-zinc-800">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              
              <div className="p-4">
                <h3 className="font-bold text-zinc-100 text-base mb-1 truncate">{item.name}</h3>
                
                <div className="flex items-center gap-2 text-xs text-zinc-400 mb-2">
                  <span className="flex items-center gap-1"><Clock size={12} /> {item.prepTime}</span>
                  <span>•</span>
                  <span>{item.distance}</span>
                </div>
                
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1">
                    <Star size={12} className="text-yellow-400 fill-yellow-400" />
                    <span className="text-xs text-yellow-400 font-bold">{item.rating}</span>
                    <span className="text-[10px] text-zinc-500">({item.reviews} Reviews)</span>
                  </div>
                  <div className="font-bold text-white">₹{item.price.toFixed(2)}</div>
                </div>

                <StatusBadge status={item.status} />

                {item.status === 'Available' || item.status === 'Running Low' ? (
                  <button 
                    onClick={() => onNavigate('checkout')}
                    className="mt-3 w-full bg-rose-600 hover:bg-rose-700 text-white font-bold py-2 rounded-xl text-sm transition-colors cursor-pointer"
                  >
                    Buy Now
                  </button>
                ) : (
                  <button disabled className="mt-3 w-full bg-zinc-800 text-zinc-500 font-bold py-2 rounded-xl text-sm cursor-not-allowed">
                    Sold Out
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Promo Banner */}
        <div className="bg-sky-500 rounded-2xl p-5 flex items-center justify-between relative overflow-hidden mb-8 shadow-lg shadow-sky-500/20">
          <div className="relative z-10">
            <div className="text-white text-lg font-bold w-4/5 mb-3 leading-tight">Up To 30% Off On First Order</div>
            <button className="bg-black/20 hover:bg-black/30 backdrop-blur-sm text-white px-4 py-1.5 rounded-full text-xs font-bold transition-colors">
              Order Now
            </button>
          </div>
          <div className="absolute -right-4 -bottom-4 w-32 h-32 opacity-80 mix-blend-overlay">
             <img src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=200" className="w-full h-full object-cover rounded-full" alt="Promo" />
          </div>
        </div>

        {/* Leaderboard Section */}
        <div className="mb-4">
           <div className="flex justify-between items-center mb-4">
             <h2 className="text-white text-lg font-bold flex items-center gap-2">
               Campus Leaderboard
             </h2>
             <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Top Rated Foods</span>
           </div>
           <div className="bg-[#18181B] rounded-2xl border border-zinc-800 p-4 space-y-4">
              {[...mockMenu].sort((a,b) => b.rating - a.rating).slice(0, 3).map((item, i) => (
                 <div key={item.id} className="flex items-center gap-4 cursor-pointer group" onClick={() => onNavigate('checkout')}>
                    <div className="w-6 text-center text-lg font-black text-zinc-600 group-hover:text-amber-500 transition-colors">#{i+1}</div>
                    <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 border border-zinc-800">
                      <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                    </div>
                    <div className="flex-1">
                       <h4 className="text-sm font-bold text-white group-hover:text-amber-500 transition-colors">{item.name}</h4>
                       <div className="flex items-center text-[10px] text-zinc-400 gap-2 mt-0.5">
                          <span className="flex items-center text-yellow-400 font-bold gap-0.5">
                            <Star size={10} className="fill-yellow-400" /> {item.rating}
                          </span>
                          <span>•</span>
                          <span>{item.reviews} Reviews</span>
                       </div>
                    </div>
                    {i === 0 && <div className="text-amber-500 drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]"><Trophy size={18}/></div>}
                 </div>
              ))}
           </div>
        </div>
      </div>
    </div>
  );
}

function CategoryPill({ active = false, label }: { active?: boolean, label: string }) {
  return (
    <button className={cn(
      "whitespace-nowrap px-4 py-2 rounded-full text-sm font-semibold transition-colors shrink-0",
      active ? "bg-rose-600 text-white" : "bg-[#18181B] text-zinc-400 hover:bg-zinc-800"
    )}>
      {label}
    </button>
  );
}

function StatusBadge({ status }: { status: string }) {
  if (status === 'Finished') {
    return <span className="inline-block px-2 text-[10px] font-bold text-zinc-500 bg-zinc-800 rounded-sm">FINISHED</span>;
  }
  if (status === 'Running Low') {
    return <span className="inline-block px-2 text-[10px] font-bold text-amber-500 bg-amber-500/10 rounded-sm">RUNNING LOW</span>;
  }
  return <span className="inline-block px-2 text-[10px] font-bold text-emerald-500 bg-emerald-500/10 rounded-sm">AVAILABLE</span>;
}
