import { Send, TrendingUp, AlertTriangle, ArrowRight, ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { cn } from '../lib/utils';

export default function VendorDashboard() {
  return (
    <div className="p-6 md:p-10 flex flex-col min-h-screen bg-black">
      <div className="flex flex-col md:flex-row md:justify-between md:items-end mb-10 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Staff Command Center</h1>
          <p className="text-sm text-zinc-400">Broadcasts, live queue, and Vouch action board.</p>
        </div>
        <div className="flex gap-2 text-sm">
          <span className="bg-emerald-500/10 text-emerald-500 font-medium px-3 py-1 rounded-full flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            System Live
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Broadcast Tool */}
        <div className="lg:col-span-2 bg-[#18181B] rounded-2xl border border-zinc-800 flex flex-col">
          <div className="p-5 border-b border-zinc-800">
            <h2 className="font-bold text-white mb-1">Live Broadcast</h2>
            <p className="text-xs text-zinc-500">Push instant updates to student Home screens.</p>
          </div>
          <div className="p-5 flex-1 flex flex-col">
            <textarea 
              placeholder="E.g. Rajma Chawal is running out fast..." 
              className="w-full bg-black border border-zinc-800 rounded-xl p-4 text-white text-sm focus:outline-none focus:border-sky-500/50 resize-none h-24 mb-4"
            ></textarea>
            
            <div className="flex flex-wrap gap-2 mb-4">
               <span className="text-[10px] uppercase font-bold text-zinc-600 self-center mr-2">Templates:</span>
               <button className="text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1 rounded-full transition-colors">Item Finished</button>
               <button className="text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1 rounded-full transition-colors">Replacing With</button>
               <button className="text-xs bg-red-500/10 hover:bg-red-500/20 text-red-400 px-3 py-1 rounded-full border border-red-500/20 transition-colors">Mess Closed</button>
            </div>
            
            <div className="mt-auto flex justify-between items-center">
              <div className="flex items-center gap-2">
                 <input type="checkbox" id="urgent" className="accent-red-500" />
                 <label htmlFor="urgent" className="text-xs font-bold text-red-500 uppercase tracking-widest">Mark Urgent</label>
              </div>
              <button className="bg-sky-500 hover:bg-sky-600 text-white font-bold px-6 py-2 rounded-xl text-sm transition-colors flex items-center gap-2">
                Send to All <Send size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Live Demand Queue */}
        <div className="bg-[#18181B] rounded-2xl border border-zinc-800 flex flex-col">
          <div className="p-5 border-b border-zinc-800 flex justify-between items-center">
            <div>
              <h2 className="font-bold text-white mb-1">Pre-order Demand</h2>
              <p className="text-xs text-zinc-500">Next 60 mins</p>
            </div>
            <div className="text-2xl font-black text-sky-500">134</div>
          </div>
          <div className="p-5 flex-1 flex flex-col gap-3">
             <DemandRow item="Rajma Chawal" count={67} max={100} color="bg-emerald-500" />
             <DemandRow item="Dal Tadka" count={43} max={100} color="bg-emerald-500" />
             <DemandRow item="Burger Deluxe" count={18} max={100} color="bg-yellow-400" />
             <DemandRow item="Chinese Fried Noodles" count={6} max={100} color="bg-zinc-600" />
          </div>
        </div>
      </div>
      
      {/* Vendor Vouch Action Board */}
      <h2 className="text-xl font-bold text-white mb-4">AI Vouch Action Board</h2>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Column title="Serve Daily" count={12} color="text-emerald-500 bg-emerald-500/10 border-emerald-500/20">
           <ActionCard item="Rajma Chawal" rating="4.8" subtext="22 orders today" trend="up" />
           <ActionCard item="Poha + Chutney" rating="4.6" subtext="high demand" trend="up" />
           <ActionCard item="Dal Tadka + Rice" rating="4.3" subtext="improving" trend="up" />
        </Column>

        <Column title="Review Recipe" count={8} color="text-yellow-400 bg-yellow-400/10 border-yellow-400/20">
           <ActionCard item="Vada Pav" rating="4.2" subtext="was 4.6 last wk" trend="down" />
           <ActionCard item="Dum Aloo" rating="3.8" subtext="was 4.1" trend="down" />
           <ActionCard item="Sambar Rice" rating="3.7" subtext="mixed reviews" trend="stale" />
        </Column>

        <Column title="Consider Removing" count={4} color="text-red-500 bg-red-500/10 border-red-500/20">
           <ActionCard item="Pav Bhaji" rating="3.2" subtext="2 weeks low" trend="down" />
           <ActionCard item="Bread Omelette" rating="2.9" subtext="high waste" trend="down" />
           <ActionCard item="Sweet Corn Soup" rating="2.7" subtext="low orders" trend="down" />
        </Column>
      </div>

      {/* Daily Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
         <MetricCard title="Total Revenue" value="₹1.4L" trend="+8% vs yesterday" />
         <MetricCard title="Food Waste Reduced" value="31%" trend="vs last month avg" />
         <MetricCard title="Pre-orders Today" value="134" trend="+18 vs yesterday" />
         <MetricCard title="Avg Rating" value="4.3" trend="+0.2 vs yesterday" />
      </div>

    </div>
  );
}

function DemandRow({ item, count, max, color }: { item: string, count: number, max: number, color: string }) {
  return (
    <div>
      <div className="flex justify-between text-xs font-bold text-white mb-1">
        <span>{item}</span>
        <span>{count}</span>
      </div>
      <div className="w-full bg-black rounded-full h-1.5">
        <div className={cn("h-1.5 rounded-full shadow-[0_0_8px_rgba(255,255,255,0.2)]", color)} style={{ width: `${(count/max)*100}%` }}></div>
      </div>
    </div>
  );
}

function Column({ title, count, color, children }: { title: string, count: number, color: string, children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-3">
      <div className={cn("px-4 py-2 rounded-t-xl border-b-2 font-bold flex justify-between items-center text-sm uppercase tracking-wide", color)}>
        {title} <span>{count}</span>
      </div>
      <div className="flex flex-col gap-3">
        {children}
      </div>
    </div>
  );
}

function ActionCard({ item, rating, subtext, trend }: { item: string, rating: string, subtext: string, trend: 'up'|'down'|'stale' }) {
  return (
    <div className="bg-[#18181B] border border-zinc-800 p-4 rounded-xl flex justify-between items-center hover:border-zinc-700 transition-colors cursor-pointer group">
       <div>
         <h4 className="font-bold text-white text-sm mb-1 group-hover:text-yellow-400 transition-colors">{item}</h4>
         <div className="flex items-center gap-2 text-xs">
           <span className="font-bold text-zinc-300">{rating}</span>
           <span className="text-zinc-600">•</span>
           <span className="text-zinc-500 leading-none">{subtext}</span>
         </div>
       </div>
       <div className="text-zinc-600">
         {trend === 'up' && <ArrowUpRight size={16} className="text-emerald-500" />}
         {trend === 'down' && <ArrowDownRight size={16} className="text-red-500" />}
         {trend === 'stale' && <ArrowRight size={16} />}
       </div>
    </div>
  );
}

function MetricCard({ title, value, trend }: { title: string, value: string, trend: string }) {
  const isPositive = trend.includes('+') || trend.includes('Reduced');
  return (
    <div className="bg-[#18181B] border border-zinc-800 p-5 rounded-2xl">
      <h4 className="text-xs text-zinc-500 font-medium mb-2">{title}</h4>
      <div className="text-2xl font-black text-white mb-2">{value}</div>
      <div className={cn("text-[10px] font-bold flex items-center gap-1", isPositive ? "text-emerald-500" : "text-yellow-400")}>
        {isPositive ? <ArrowUpRight size={12} /> : <AlertTriangle size={12} />} {trend}
      </div>
    </div>
  );
}
